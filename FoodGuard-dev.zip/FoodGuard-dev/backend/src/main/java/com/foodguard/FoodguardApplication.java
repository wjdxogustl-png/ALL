package com.foodguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodguardApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodguardApplication.class, args);
	}

}
