package com.foodguard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodguardApplicationTests {

	@Test
	void contextLoads() {
	}

}
